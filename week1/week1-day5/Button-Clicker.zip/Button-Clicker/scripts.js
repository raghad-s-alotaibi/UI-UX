function hide(element) {
    element.remove();
}
function changeText(element) {
    element.innerText = "Logout"
  }