function hide(element) {
    document.getElementById("message").remove();
}

function convert(element) {
    document.getElementById("temp1").innerHTML = "75";
    document.getElementById("temp2").innerHTML = "65";
    document.getElementById("temp3").innerHTML = "80";
    document.getElementById("temp4").innerHTML = "66";
    document.getElementById("temp5").innerHTML = "69";
    document.getElementById("temp6").innerHTML = "61";
    document.getElementById("temp7").innerHTML = "78";
    document.getElementById("temp8").innerHTML = "70";
  }